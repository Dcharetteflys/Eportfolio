#!/usr/bin/env python
# coding: utf-8

# ----------------------------------------------------------
# Import Required Libraries
# ----------------------------------------------------------
# Import the AnimalShelter class used to perform CRUD
# operations on the MongoDB database.
# Import ObjectId from bson for handling MongoDB object IDs.

# In[1]:

from ANIMALSHELTER import AnimalShelter
from bson.objectid import ObjectId


# ----------------------------------------------------------
# Create AnimalShelter Object and Database Connection
# ----------------------------------------------------------
# Define the username and password used to authenticate
# with the MongoDB database and create an AnimalShelter
# object for performing database operations.

# In[2]:

USER ='aacuser'
PASS = 'pass1'
animals = AnimalShelter(USER, PASS)


# ----------------------------------------------------------
# CREATE Operation
# ----------------------------------------------------------
# Create a dictionary containing the information for a new
# animal record and insert it into the database.

# In[3]:

animal_data = {
    'rec_num': 1002,
    'age_upon_outcome': "6 Months",
    'animal_id': "A1002",
    'animal_type': "Cat",
    'breed': "short Hair",
    'color': "Black",
    'date_of_birth': "2024-01-12",
    'datetime':"",
    'monthyear': "2",
    'name': "CatDog",
    'outcome_subtype': "adoption",
    'sex_upon_outcome': "Male",
}

result = animals.create(animal_data)
print("insert successful", result)


# ----------------------------------------------------------
# CREATE Operation Error Test
# ----------------------------------------------------------
# Attempt to insert invalid data to test how the create
# method handles improper input.

# In[4]:

print(animals.create({0:0}))


# ----------------------------------------------------------
# READ Operation – Search by Name
# ----------------------------------------------------------
# Search the database for records where the animal's name
# matches "CatDog" and display the results.

# In[5]:

search_filter = {'name': 'CatDog'}
results = animals.read(search_filter)

if results:
    for animal in results:
        print(animal)
else:
    print("no matches")


# ----------------------------------------------------------
# READ Operation – Display Multiple Records
# ----------------------------------------------------------
# Retrieve all records from the database and display only
# the first 20 records.

# In[8]:

results = animals.read({})
for i, r in enumerate(results):
    if i >=20:
        break
    print(r)


# ----------------------------------------------------------
# READ Operation Error Test
# ----------------------------------------------------------
# Attempt to perform a read operation using invalid search
# criteria to test error handling.

# In[7]:

print(list(animals.read({0.0})))


# ----------------------------------------------------------
# UPDATE Operation
# ----------------------------------------------------------
# Update the record for the animal named "CatDog" by adding
# or changing the outcome_type field to "Adopted".

# In[9]:

updateAnimal = animals.update({"name": "CatDog"}, {"outcome_type": "Adopted"})
print(updateAnimal)


# ----------------------------------------------------------
# VERIFY UPDATE
# ----------------------------------------------------------
# Read and display the updated record to confirm that the
# update operation was successful.

# In[10]:

query = animals.read({"name": "CatDog"})
for animal in query:
    print(animal)


# ----------------------------------------------------------
# DELETE Operation
# ----------------------------------------------------------
# Delete the record associated with the animal named
# "CatDog" from the database.

# In[11]:

deleteAnimal = animals.delete({"name": "CatDog"})
print(deleteAnimal)


# ----------------------------------------------------------
# VERIFY DELETE
# ----------------------------------------------------------
# Attempt to retrieve the deleted record to verify that it
# was successfully removed from the database.

# In[12]:

query = animals.read({"name": "CatDog"})
for animal in query:
    print(animal)


# In[ ]: