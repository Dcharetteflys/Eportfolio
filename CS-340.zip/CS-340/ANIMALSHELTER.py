#!/usr/bin/env python
# coding: utf-8

# ----------------------------------------------------------
# Student Information
# ----------------------------------------------------------
# Name: David Charette
# Course: CS-340
# Date: 5/30/2025

# In[2]:


#David Charette
#CS-340 
#5/30/2025

# ----------------------------------------------------------
# Import Required Libraries
# ----------------------------------------------------------
# MongoClient is used to establish a connection to MongoDB.
# ObjectId allows handling MongoDB document IDs.
# pprint provides formatted output when displaying documents.

from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint


# ----------------------------------------------------------
# AnimalShelter Class Definition
# ----------------------------------------------------------

class AnimalShelter(object):
    """ CRUD operations for Animal collections in MongoDB """

    # ------------------------------------------------------
    # Constructor Method 
    # ------------------------------------------------------
    # Initializes the MongoDB client connection and provides
    # access to the AAC database and animals collection.
    
    def __init__(self,USER, PASS):
        
        # intializing the mongo client
        # access the mongoDB databases and collections
        
        USER = 'aacuser'
        PASS = 'pass1'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32530
        DB = 'AAC'
        COL = 'animals'

        try:
            self.client = MongoClient(
                'mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]
            print("connection good")

        except PyMongoError as e:
            print(f"Error connection: {e}")


    # ------------------------------------------------------
    # CREATE Method
    # ------------------------------------------------------
    # Inserts a new document into the animals collection.
    # Returns True if insertion is successful and False
    # if an error occurs.

    # complete this create method to implement C in CRUD.def create(self, data):
    
    def create(self, data):
        if data is not None and isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                print(f"Document inserted with ID:{result.inserted_id}")
                return True if result.inserted_id else False

            except PyMongoError as e:
                print(f"Error iserting: {e}")
                return False

        else:
            raise ValueError(
                "Nothing to save, because data parameter is empty"
            )


    # ------------------------------------------------------
    # READ Method
    # ------------------------------------------------------
    # Searches the collection using the provided query.
    # Returns a list of matching documents.

    # create method to implement R in crud.
    
    def read(self, query):
        if query is not None and isinstance(query, dict):
            try:
                cursor = self.collection.find(query)
                result = list(cursor) if cursor else []
                print(f"Query returned {len(result)} document")
                return result

            except PyMongoError as e:
                print(f"Error reading: {e}")
                return []

        else:
            raise ValueError(
                "Nothing to read, because data parameter is empty"
            )


    # ------------------------------------------------------
    # UPDATE Method
    # ------------------------------------------------------
    # Updates documents matching the query using the
    # provided new values.
    # Returns the number of modified documents.

    # create mmethod to implemetn U in crud
    
    def update(self, query, new_value):
        if (
            query is not None and isinstance(query, dict)
            and new_value is not None and isinstance(new_value, dict)
        ):
            try:
                result = self.collection.update_many(
                    query,
                    {"$set": new_value}
                )
                return result.modified_count

            except PyMongoError as e:
                print(f"Error updating: {e}")
                return 0

        else:
            raise ValueError(
                "Nothing to update, because data parameter is empty"
            )


    # ------------------------------------------------------
    # DELETE Method
    # ------------------------------------------------------
    # Deletes documents matching the query.
    # Returns the number of deleted documents.

    # create method to implement D in crud

    def delete(self, query):
        if query is not None and isinstance(query, dict):
            try:
               result = self.collection.delete_many(query)
               return result.deleted_count

            except PyMongoError as e:
                print(f"Error deleting: {e}")
                return 0

        else:
            raise ValueError(
                "Nothing to delete, because data parameter is empty"
            )



# In[ ]: